import React from 'react'
import ZigZagClimber from './ZigZagClimber'

export default function App(){
  return <ZigZagClimber />
}
